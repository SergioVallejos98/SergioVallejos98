package juego;

public class Auto {

}
