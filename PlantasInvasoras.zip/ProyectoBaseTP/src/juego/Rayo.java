package juego;

public class Rayo {

}
