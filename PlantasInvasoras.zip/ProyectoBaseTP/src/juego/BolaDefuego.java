package juego;

public class BolaDefuego {

}
